# Icons

The `.svg` icons contained in this folder were downsized with

    svgo -f ./actions ./actions_new

in `fe5d254f2e22e213b2e2b1945e83432c1e36806e`.

The original icons, before downsizing, are still present in the git history in the last commit before the downsizing `86e1939ef4f6aeccffc66395fcf820f023316450`.
In case these files are preferable when working with the icon files please consider checking out this commit.
